﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ealshanta_InClass1_Calculator
{
    public partial class Calculator : Form
    {
        double operand1 = 0.0;              // First entry 
        double operand2 = 0.0;              // Second entry
        double answer = 0.0;
        char operation = ' ';

        public Calculator()
        {
            InitializeComponent();
        }
        
        // Load
        private void Calculator_Load(object sender, EventArgs e)
        {
            lblAnswer.Text = "0";
            lblDisplay.Text = "0";
        }

        // Button 1
        private void btnOne_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 1;
                lblDisplay.Text = operand1.ToString();
            }
            else
            {
                operand2 = 1;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
            if (operand2 == ' ')
            {

            }
            else
            {
                operand1 = 1;
            }
        }

        // Button 2
        private void btnTwo_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 2;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 2;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 3
        private void btnThree_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 3;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 3;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 4
        private void btnFour_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 4;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 4;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 5
        private void btnFive_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 5;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 5;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 6
        private void btnSix_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 6;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 6;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 7
        private void btnSeven_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 7;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 7;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 8
        private void btnEight_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 8;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 8;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 9
        private void btnNine_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 9;
                lblDisplay.Text = operand1.ToString() + operation;
            }
            else
            {
                operand2 = 9;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button 0
        private void btnZero_Click(object sender, EventArgs e)
        {
            if (operation == ' ')
            {
                operand1 = 0;
                lblDisplay.Text = operand1.ToString() + operation;
            }          
            else
            {
                operand2 = 0;
                lblDisplay.Text = operand1.ToString() + operation + operand2.ToString();
            }
        }

        // Button Add (+) 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            operation = '+';
            lblDisplay.Text = operand1.ToString() + operation;
        }

        // Button Subtract (-)
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            operation = '-';
            lblDisplay.Text = operand1.ToString() + operation;
        }

        // Button Multiply (*)
        private void btnMultiply_Click(object sender, EventArgs e)
        {
            operation = '*';
            lblDisplay.Text = operand1.ToString() + operation;
        }

        // Button Division (/)
        private void btnDivide_Click(object sender, EventArgs e)
        {
            operation = '%';
            lblDisplay.Text = operand1.ToString() + operation;
        }

        // Button Equal (=)
        private void btnEqual_Click(object sender, EventArgs e)
        {
            if (operation == '+')
            {
                answer = operand1 + operand2;
                lblAnswer.Text = answer.ToString();
            }
            else if (operation == '-')
            {
                answer = operand1 - operand2;
                lblAnswer.Text = answer.ToString();
            }
            else if (operation == '%')
            {
                answer = operand1 % operand2;
                lblAnswer.Text = answer.ToString();
            }
            else if (operation == '*')
            {
                answer = operand1 * operand2;
                lblAnswer.Text = answer.ToString();
            }
        }

        // Button Clear (C)
        private void btnClear_Click(object sender, EventArgs e)
        {
            lblAnswer.Text = "0";
        }

        // Button Clear All (CE)
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            // reset all entries to zero  
            lblDisplay.Text = "0";
            lblAnswer.Text = "0";
        }
    }
}
